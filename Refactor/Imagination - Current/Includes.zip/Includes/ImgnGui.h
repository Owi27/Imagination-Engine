#pragma once
#include "ResourceTypes.h"
#include "ImgnWindow.h"
#include "ImGui/imgui.h"
#include "ImGui/imgui_impl_win32.h"
#include "ImGui/imgui_impl_vulkan.h"

class ImgnGui
{
	struct ImGuiPushConst
	{
		Math::vec2<float> scale, translate;
	} _imGuiPushConst;

	Image _font;
	Buffer _vertex, _idx;
	vk::raii::Sampler _sampler = nullptr;
	uint32_t _vertexCount = 0, _idxCount = 0;

	vk::raii::PipelineCache _pipelineCache = nullptr;  
	vk::raii::PipelineLayout _pipelineLayout = nullptr;
	vk::raii::Pipeline _pipeline = nullptr;            
	vk::raii::DescriptorPool _descriptorPool = nullptr;
	vk::raii::DescriptorSetLayout _descriptorSetLayout = nullptr;
	vk::raii::DescriptorSet _descriptorSet = nullptr;
	vk::PipelineRenderingCreateInfo _renderingInfo = {};

	bool _needsUpdateBuffers = false;
	vk::Format _colorFormat = vk::Format::eB8G8R8A8Unorm;

	void CreateResources();
	uint32_t FindMemoryType(uint32_t pTypeFilter, vk::MemoryPropertyFlags pProps);


public:
	ImgnGui()
	{
		/*vk::raii::Device device = Device::Inst().GetDevice();

		vk::BufferCreateInfo bufferCreateInfo
		{
			.size = pSize,
			.usage = pUsage,
			.sharingMode = vk::SharingMode::eExclusive
		};

		pBuffer.buffer = vk::raii::Buffer(Device::Inst().GetDevice(), bufferCreateInfo);

		vk::MemoryRequirements memReqs = pBuffer.buffer.getMemoryRequirements();
		vk::MemoryAllocateInfo memoryAllocateInfo{ .allocationSize = memReqs.size, .memoryTypeIndex = FindMemoryType(memReqs.memoryTypeBits, pProps) };

		pBuffer.memory = vk::raii::DeviceMemory(Device::Inst().GetDevice(), memoryAllocateInfo);

		pBuffer.buffer.bindMemory(*pBuffer.memory, 0);*/

		_renderingInfo.colorAttachmentCount = 1;
		vk::Format formats[] = { _colorFormat };
		_renderingInfo.pColorAttachmentFormats = &_colorFormat;

	}

	~ImgnGui()
	{
		ImGui_ImplVulkan_Shutdown();
		ImGui_ImplWin32_Shutdown();
		ImGui::DestroyContext();
	}

	void Init(ImgnWindow& pWin, float pWidth, float pHeight);

	//bool NewFrame();
	//void UpdateBuffers();
	void DrawFrame(vk::raii::CommandBuffer& pCommandBuffer);
};

