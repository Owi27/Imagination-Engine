#pragma once

// Generic bitmask operator enable
template <typename Enum>
struct EnableBitMaskOperators : std::false_type {};

template <typename Enum>
concept BitmaskEnum = std::is_enum_v<Enum> && EnableBitMaskOperators<Enum>::value;

// Bitwise OR
template <BitmaskEnum E>
constexpr E operator|(E lhs, E rhs) noexcept
{
	using U = std::underlying_type_t<E>;
	return static_cast<E>(static_cast<U>(lhs) | static_cast<U>(rhs));
}

// Bitwise AND
template <BitmaskEnum E>
constexpr E operator&(E lhs, E rhs) noexcept
{
	using U = std::underlying_type_t<E>;
	return static_cast<E>(static_cast<U>(lhs) & static_cast<U>(rhs));
}

// Bitwise XOR
template <BitmaskEnum E>
constexpr E operator^(E lhs, E rhs) noexcept
{
	using U = std::underlying_type_t<E>;
	return static_cast<E>(static_cast<U>(lhs) ^ static_cast<U>(rhs));
}

// Bitwise NOT
template <BitmaskEnum E>
constexpr E operator~(E e) noexcept
{
	using U = std::underlying_type_t<E>;
	return static_cast<E>(~static_cast<U>(e));
}

// Compound OR
template <BitmaskEnum E>
constexpr E& operator|=(E& lhs, E rhs) noexcept
{
	lhs = lhs | rhs;
	return lhs;
}

// Compound AND
template <BitmaskEnum E>
constexpr E& operator&=(E& lhs, E rhs) noexcept
{
	lhs = lhs & rhs;
	return lhs;
}

// Compound XOR
template <BitmaskEnum E>
constexpr E& operator^=(E& lhs, E rhs) noexcept
{
	lhs = lhs ^ rhs;
	return lhs;
}

enum class PipelineFormat
{
	FLOAT = VK_FORMAT_R32_SFLOAT,
	FLOAT2 = VK_FORMAT_R32G32_SFLOAT,
	FLOAT3 = VK_FORMAT_R32G32B32_SFLOAT,
	FLOAT4 = VK_FORMAT_R32G32B32A32_SFLOAT,
	HFLOAT = VK_FORMAT_R16_SFLOAT,
	HFLOAT2 = VK_FORMAT_R16G16_SFLOAT,
	HFLOAT3 = VK_FORMAT_R16G16B16_SFLOAT,
	HFLOAT4 = VK_FORMAT_R16G16B16A16_SFLOAT,
	INT = VK_FORMAT_R32_SINT,
	INT2 = VK_FORMAT_R32G32_SINT,
	INT3 = VK_FORMAT_R32G32B32_SINT,
	INT4 = VK_FORMAT_R32G32B32A32_SINT,
	UINT = VK_FORMAT_R32_UINT,
	UINT2 = VK_FORMAT_R32G32_UINT,
	UINT3 = VK_FORMAT_R32G32B32_UINT,
	UINT4 = VK_FORMAT_R32G32B32A32_UINT,
	COLOR2 = VK_FORMAT_R8G8_UNORM,
	COLOR3 = VK_FORMAT_R8G8B8_UNORM,
	COLOR = VK_FORMAT_R8G8B8A8_UNORM,
	SWAPCHAIN = VK_FORMAT_B8G8R8A8_SRGB,
	DEPTH32_STENCIL8 = VK_FORMAT_D32_SFLOAT_S8_UINT,
	DEPTH32 = VK_FORMAT_D32_SFLOAT,
	DEPTH24_STENCIL8 = VK_FORMAT_D24_UNORM_S8_UINT,
	DEPTH16_STENCIL8 = VK_FORMAT_D16_UNORM_S8_UINT,
	DEPTH16 = VK_FORMAT_D16_UNORM,
	UNDEFINED = VK_FORMAT_UNDEFINED
};

enum class Topology
{
	POINT = VK_PRIMITIVE_TOPOLOGY_POINT_LIST,
	LINE_LIST = VK_PRIMITIVE_TOPOLOGY_LINE_LIST,
	LINE_STRIP = VK_PRIMITIVE_TOPOLOGY_LINE_STRIP,
	TRIANGLE_LIST = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST,
	TRIANGLE_STRIP = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_STRIP
};

enum class PolygonMode
{
	FILL = VK_POLYGON_MODE_FILL,
	LINE = VK_POLYGON_MODE_LINE
};

enum class CullMode
{
	FRONT = VK_CULL_MODE_FRONT_BIT,
	BACK = VK_CULL_MODE_BACK_BIT,
	NONE = VK_CULL_MODE_NONE
};

enum class FrontFace
{
	COUNTER_CLOCKWISE = VK_FRONT_FACE_COUNTER_CLOCKWISE,
	CLOCKWISE = VK_FRONT_FACE_CLOCKWISE
};

enum class BlendFactor
{
	FULL = VK_BLEND_FACTOR_ONE,
	NONE = VK_BLEND_FACTOR_ZERO,
	SOURCE_ALPHA = VK_BLEND_FACTOR_SRC_ALPHA,
	NEG_SOURCE_ALPHA = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA
};

enum class BlendOperation
{
	ADD = VK_BLEND_OP_ADD,
	SUBTRACT = VK_BLEND_OP_SUBTRACT,
	MIN = VK_BLEND_OP_MIN,
	MAX = VK_BLEND_OP_MAX
};

enum class ColorComponent
{
	R = VK_COLOR_COMPONENT_R_BIT,
	G = VK_COLOR_COMPONENT_G_BIT,
	B = VK_COLOR_COMPONENT_B_BIT,
	A = VK_COLOR_COMPONENT_A_BIT
};

enum class SampleCount
{
	SAMPLE_1BIT = VK_SAMPLE_COUNT_1_BIT,
	SAMPLE_2BIT = VK_SAMPLE_COUNT_2_BIT,
	SAMPLE_4BIT = VK_SAMPLE_COUNT_4_BIT,
	SAMPLE_8BIT = VK_SAMPLE_COUNT_8_BIT,
	SAMPLE_16BIT = VK_SAMPLE_COUNT_16_BIT,
	SAMPLE_32BIT = VK_SAMPLE_COUNT_32_BIT,
	SAMPLE_64BIT = VK_SAMPLE_COUNT_64_BIT,
};

enum class BufferUsage
{
	SOURCE = VK_BUFFER_USAGE_TRANSFER_SRC_BIT,
	DESTINATION = VK_BUFFER_USAGE_TRANSFER_DST_BIT,
	UNIFORM = VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT,
	STORAGE = VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,
	INDEX = VK_BUFFER_USAGE_INDEX_BUFFER_BIT,
	VERTEX = VK_BUFFER_USAGE_VERTEX_BUFFER_BIT,
	DEVICE_ADDRESS = VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT,
	DESCRIPTOR = VK_BUFFER_USAGE_RESOURCE_DESCRIPTOR_BUFFER_BIT_EXT,
	DESCRIPTOR_SAMPLER = VK_BUFFER_USAGE_SAMPLER_DESCRIPTOR_BUFFER_BIT_EXT
};
template <> struct EnableBitMaskOperators<BufferUsage> : std::true_type {};

enum class MemoryFlags
{
	GPU = VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT,
	CPU = VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT,
	CPU2GPU = VK_MEMORY_PROPERTY_HOST_COHERENT_BIT,
	TRANSIENT = VK_MEMORY_PROPERTY_LAZILY_ALLOCATED_BIT
};
template <> struct EnableBitMaskOperators<MemoryFlags> : std::true_type {};

enum class ImageTiling
{
	OPTIMAL = VK_IMAGE_TILING_OPTIMAL,
	LINEAR = VK_IMAGE_TILING_LINEAR,
};

enum class ImageUsage
{
	SOURCE = VK_IMAGE_USAGE_TRANSFER_SRC_BIT,
	DESTINATION = VK_IMAGE_USAGE_TRANSFER_DST_BIT,
	SAMPLED = VK_IMAGE_USAGE_SAMPLED_BIT,
	STORAGE = VK_IMAGE_USAGE_STORAGE_BIT,
	COLOR_ATTACHMENT = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT,
	DEPTH_STENCIL = VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT,
	TRANSIENT = VK_IMAGE_USAGE_TRANSIENT_ATTACHMENT_BIT,
	INPUT_ATTACHMENT = VK_IMAGE_USAGE_INPUT_ATTACHMENT_BIT
};
template <> struct EnableBitMaskOperators<ImageUsage> : std::true_type {};

enum class ImageLayout
{
	GENERAL = VK_IMAGE_LAYOUT_GENERAL,
	COLOR_ATTACHMENT = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL,
	DEPTH_STENCIL = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL,
	DEPTH_STENCIL_READ = VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL,
	SHADER_READ = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,
	SOURCE = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
	DESTINATION = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
	//ATTACHMENT_OPTIMAL = VK_IMAGE_LAYOUT_ATTACHMENT_OPTIMAL,
	//READ_ONLY_OPTIMAL = VK_IMAGE_LAYOUT_READ_ONLY_OPTIMAL,
	PRESENT_SRC = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR,
	UNDEFINED = VK_IMAGE_LAYOUT_UNDEFINED
};

enum class ImageAspect
{
	COLOR = VK_IMAGE_ASPECT_COLOR_BIT,
	DEPTH = VK_IMAGE_ASPECT_DEPTH_BIT,
	STENCIL = VK_IMAGE_ASPECT_STENCIL_BIT
};
template <> struct EnableBitMaskOperators<ImageAspect> : std::true_type {};

enum class LoadOp
{
	KEEP = VK_ATTACHMENT_LOAD_OP_LOAD, //keep whats in the attachment
	CLEAR = VK_ATTACHMENT_LOAD_OP_CLEAR, //erase the attachment
	TRASH = VK_ATTACHMENT_LOAD_OP_DONT_CARE //throw away
};

enum class StoreOp
{
	STORE = VK_ATTACHMENT_STORE_OP_STORE, //store result
	TRASH = VK_ATTACHMENT_STORE_OP_DONT_CARE //throw away
};

enum class ShaderStage
{
	VERTEX = VK_SHADER_STAGE_VERTEX_BIT,
	FRAGMENT = VK_SHADER_STAGE_FRAGMENT_BIT,
};
template <> struct EnableBitMaskOperators<ShaderStage> : std::true_type {};

enum class DescriptorType
{
	IMAGE_SAMPLER = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,
	UNIFORM_BUFFER = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER,
	STORAGE_BUFFER = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,
	INPUT_ATTACHMENT = VK_DESCRIPTOR_TYPE_INPUT_ATTACHMENT,
};