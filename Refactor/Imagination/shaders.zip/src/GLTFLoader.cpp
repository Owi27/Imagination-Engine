#include "pch.h"
#include "GLTFLoader.h"

void GLTFLoader::LoadModel(const std::string& filepath)
{
	tinygltf::TinyGLTF gltfLoader;
	std::string error;
	std::string warning;

	//unsigned long long pos = filename.find_last_of('/');
	//std::string path = filename.substr(0, pos);

	bool fileLoaded = gltfLoader.LoadASCIIFromFile(_model.get(), &error, &warning, filepath);
	//tinygltf::Model& model = _models[id];

	if (!warning.empty())
	{
		std::cout << "Warning: " << warning << '\n';
	}

	if (!error.empty())
	{
		std::cout << "Error: " << error << '\n';
	}

	if (!fileLoaded)
	{
		std::cout << "Failed to parse model\n";
	}
}
