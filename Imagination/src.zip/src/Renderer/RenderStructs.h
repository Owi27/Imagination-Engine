#pragma once

namespace Imgn
{
	enum class eMaterialTexture : uint8_t
	{
		BaseColor,
		MetallicRoughness,
		Emissive,
		Normal,
		Occlusion,
		Count
	};

	struct Vertex
	{
		vec3 pos;
		vec3 nrm;
		vec2 uv0;
		vec4 tan;
		vec3 clr = { 1.0f, 1.0f, 1.0f };
		uvec4 joints;
		vec4 weights;
		int entityID; //editor only

		//vk
		static vk::VertexInputBindingDescription GetBindingDescription() { return { 0, sizeof(Vertex), vk::VertexInputRate::eVertex }; }
		static std::array<vk::VertexInputAttributeDescription, 5> GetAttributeDescriptions()
		{
			return
			{
				vk::VertexInputAttributeDescription(0, 0, vk::Format::eR32G32B32Sfloat, offsetof(Vertex, pos)),
				vk::VertexInputAttributeDescription(1, 0, vk::Format::eR32G32B32Sfloat, offsetof(Vertex, nrm)),
				vk::VertexInputAttributeDescription(2, 0, vk::Format::eR32G32Sfloat, offsetof(Vertex, uv0)),
				vk::VertexInputAttributeDescription(3, 0, vk::Format::eR32G32B32A32Sfloat, offsetof(Vertex, tan)),
				vk::VertexInputAttributeDescription(4, 0, vk::Format::eR32G32B32Sfloat, offsetof(Vertex, clr)),
			};
		}
	};

	struct TextureSource
	{
		std::string path;
		int32_t imageIndex = -1;
		bool srgb = false;

		bool operator==(const TextureSource&) const = default;
	};

	struct Material
	{
		std::array<float, 4> baseColorFactor = { 1.f, 1.f, 1.f, 1.f }, emissiveFactor;

		// x = base color
		// y = metallic/roughness
		// z = emissive
		// w = normal
		std::array<int32_t, 4> textureIndices0;

		// x = occlusion
		// y = alpha mode
		// z = double sided
		// w = unused
		std::array<int32_t, 4> textureIndices1;

		// x = metallic
		// y = roughness
		// z = alpha cutoff
		// w = normal scale
		std::array<float, 4> materialFactors;

		// x = occlusion strength
		// yzw = unused
		std::array<float, 4> extraFactors;

		int32_t GetTexture(eMaterialTexture pTexture) const
		{
			uint32_t index = static_cast<uint32_t>(pTexture);
			if (index < 4) return textureIndices0[index];
			return pTexture == eMaterialTexture::Occlusion ? textureIndices1[0] : -1;
		}

		bool SetTexture(eMaterialTexture pTexture, int32_t pTextureHandle)
		{
			uint32_t index = static_cast<uint32_t>(pTexture);
			if (index >= static_cast<uint32_t>(eMaterialTexture::Count)) return false;

			if (index < 4) textureIndices0[index] = pTextureHandle;
			else textureIndices1[0] = pTextureHandle;

			return true;
		}
	};

	struct ImgnPrimitive
	{
		std::string name;

		int vertexOffset = 0;
		uint32_t firstIndex = 0, indexCount = 0, firstVertex = 0, vertexCount = 0, material = InvalidHandle;
	};


	struct ImgnMesh
	{
		std::string name;

		uint32_t vertexBuffer = InvalidHandle, indexBuffer = InvalidHandle;

		std::vector<ImgnPrimitive> primitives;

		std::string sourcePath;
		uint32_t sourceMeshIdx = 0;
	};
}

enum class RendererBackend
{
	Vulkan, D3D12, Metal
};

struct RendererCreateInfo
{
	RendererBackend backend = RendererBackend::Vulkan;

	void* windowHandle = nullptr, * displayHandle = nullptr;

	uint32_t width = 1280, height = 720;

	bool enableValidation = true;
};
