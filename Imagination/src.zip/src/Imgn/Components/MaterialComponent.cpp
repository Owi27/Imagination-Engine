#include "pch.hpp"
#include "MaterialComponent.h"

namespace Imgn
{
}