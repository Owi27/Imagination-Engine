#pragma once
#include "Imgn/ImgnComponent.h"
#include "MaterialComponent.h"

struct Buffer;
struct Image;

namespace Imgn
{
	struct Primitive
	{
		uint32_t firstIndex = 0, indexCount = 0, firstVertex = 0, vertexCount = 0, vertexOffset = 0, material = InvalidHandle;
	};

	class IMGN_API MeshComponent : public Component
	{
		std::string _name;
		unique<Buffer> _vertex, _index;
		std::filesystem::path _assetPath;
		std::vector<Primitive> _primitives;
		std::vector<shared<Material>> _materials;

		static bool ReadString(std::fstream& pStream, std::string& pValue);
		static void WriteString(std::fstream& pStream, const std::string& pValue);

	public:
		IMGN_COMPONENT_ID("Imgn.MeshComponent");
		
		MeshComponent() : Component("Mesh") /*Constructor*/
		{
		}

		~MeshComponent() /*Destructor*/
		{
		}

		Buffer* GetVertexBuffer() { return _vertex.get(); }
		Buffer* GetIndexBuffer() { return _index.get(); }
		const std::vector<Primitive>& GetPrimitives() const { return _primitives; }

		void SetMesh(std::filesystem::path& pAssetPath);

		bool visible = true;


		void Serialize(std::fstream& pStream) override;
		void Deserialize(std::fstream& pStream) override;
	};
}