#include "pch.hpp"
#include "MeshComponent.h"

namespace Imgn
{
	void Imgn::MeshComponent::SetMesh(std::filesystem::path& pAssetPath)
	{
		_assetPath = pAssetPath;


	}
}