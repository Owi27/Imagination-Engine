#pragma once
#include "Imgn/ImgnComponent.h"

struct Image;

namespace Imgn
{
	struct Material
	{
		shared<Image>
	};

    class IMGN_API MaterialComponent : public Component
    {
		/*std::string name;

		uint32_t vertexBuffer = InvalidHandle, indexBuffer = InvalidHandle;

		std::vector<ImgnPrimitive> primitives;

		std::string sourcePath;
		uint32_t sourceMaterialIdx = 0;*/

		std::string _name;
		unique<Buffer> vertex, index;
		std::vector<Primitive> _primitives;
        //uint32_t _Material = InvalidHandle;
        //std::vector<Material> _materials;

        static bool ReadString(std::fstream& pStream, std::string& pValue);
        static void WriteString(std::fstream& pStream, const std::string& pValue);

    public:
		IMGN_COMPONENT_ID("Imgn.MaterialComponent");
		
		MaterialComponent() : Component("Materials") /*Constructor*/
		{
		}

		~MaterialComponent() /*Destructor*/
		{
		}

		void Serialize(std::fstream& pStream) override;
		void Deserialize(std::fstream& pStream) override;
    };
}