#include "pch.hpp"
#include "ImgnGui.h"
#include "Imgn/ImgnApp.hpp"

#include "ImGui/imgui_impl_win32.h"
#include "ImGui/imgui_impl_vulkan.h"

namespace Imgn
{
	int ImGuiLayer::ImGui_ImplWin32_CreateVkSurface(ImGuiViewport* pViewport, ImU64 pVkInstance, const void* pVkAllocator, ImU64* pOutSurface)
	{
		VkWin32SurfaceCreateInfoKHR createInfo
		{
			.sType = VK_STRUCTURE_TYPE_WIN32_SURFACE_CREATE_INFO_KHR,
			.hinstance = GetModuleHandle(nullptr),
			.hwnd = (HWND)pViewport->PlatformHandleRaw
		};

		return (int)vkCreateWin32SurfaceKHR((VkInstance)pVkInstance, &createInfo, (const VkAllocationCallbacks*)pVkAllocator, (VkSurfaceKHR*)pOutSurface);
	}

	void ImGuiLayer::Sleep()
	{
		ImGui::CreateContext();
		ImGui::StyleColorsDark();

		ImGuiIO& io = ImGui::GetIO();
		io.BackendFlags |= ImGuiBackendFlags_HasMouseCursors;
		io.BackendFlags |= ImGuiBackendFlags_HasSetMousePos;

		ImGui_ImplWin32_Init(_window->GetWindowHandle());
		ImGui::GetPlatformIO().Platform_CreateVkSurface = ImGui_ImplWin32_CreateVkSurface;

		ImGui_ImplVulkan_InitInfo initInfo = _renderer->GetImGuiInitInfo();

		ImGui_ImplVulkan_Init(&initInfo);
	}

	void ImGuiLayer::WakeUp()
	{
	}

	void ImGuiLayer::Dream(Time pTime)
	{
		ImGuiIO& io = ImGui::GetIO();
		io.DisplaySize = ImVec2(_window->GetWidth(), _window->GetHeight());
		io.DeltaTime = pTime;
		ImGui_ImplVulkan_NewFrame();
		ImGui_ImplWin32_NewFrame();
		ImGui::NewFrame();


		ImGui::ShowDemoWindow();
		ImGui::Begin("Style");
		ImGui::ShowStyleEditor();
		ImGui::End();


		ImGui::Render();
		vk::raii::CommandBuffer& commandBuffer = _renderer->GetActiveCommandBuffer();
		vk::RenderingAttachmentInfo colorAttachment
		{
			.imageView = _renderer->GetActiveSwapchainImageView(),
			.imageLayout = vk::ImageLayout::eColorAttachmentOptimal,
			.loadOp = vk::AttachmentLoadOp::eLoad,
			.storeOp = vk::AttachmentStoreOp::eStore
		};

		vk::RenderingInfo renderingInfo
		{
			.renderArea =
			{
				.offset = { 0, 0 },
				.extent = _renderer->GetSwapchainExtent()
			},
			.layerCount = 1,
			.colorAttachmentCount = 1,
			.pColorAttachments = &colorAttachment
		};

		commandBuffer.beginRendering(renderingInfo);

		ImGui_ImplVulkan_RenderDrawData(ImGui::GetDrawData(), *commandBuffer);

		commandBuffer.endRendering();
	}

	void ImGuiLayer::OnEvent(Event& pEvent)
	{

	}
}