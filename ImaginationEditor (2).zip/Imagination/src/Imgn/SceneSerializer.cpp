#include "pch.hpp"
#include "SceneSerializer.h"

namespace Imgn
{
	struct SceneFileHeader
	{
		std::array<char, 4> magic = { 'I', 'M', 'G', 'N'};
		uint32_t version = 1;
		uint32_t entityCount = 0;
	};

	struct MyStruct
	{

	};
	void SceneSerializer::Serialize(const std::string& filepath)
	{
	}
	void SceneSerializer::Serialize(const std::filesystem::path& pFilepath)
	{
		_stream = std::fstream(pFilepath, std::ios::binary);
		SceneFileHeader fileHeader;
		std::string entityHeader = "Entity";

		Write(&fileHeader, sizeof(SceneFileHeader));
		Write(entityHeader.data(), entityHeader.size());



	}
	void SceneSerializer::SerializeRuntime(const std::string& filepath)
	{
	}
	bool SceneSerializer::Deserialize(const std::string& filepath)
	{
		return false;
	}
	bool SceneSerializer::DeserializeRuntime(const std::string& filepath)
	{
		return false;
	}

	void SceneSerializer::WriteString(const std::string& pValue)
	{
		uint32_t length = static_cast<uint32_t>(pValue.size());

		Write(length);

		if (length > 0) Write

	}
}
