#include "pch.hpp"
#include "ImgnScene.h"
#include "Components/ImgnComponents.h"

namespace Imgn
{
	void Scene::Dream(Time pTime)
	{
		for (auto& entity : _entities)
		{
			if (entity->GetComponent<TransformComponent>())
			{

			}
		}
	}

	Entity* Scene::CreateEntity(const std::string& pName)
	{
		_entities.emplace_back(Unique<Entity>(pName));
		_entities.back()->AddComponent<TransformComponent>();

		return &*_entities.back();
	}

	void Scene::OnViewportResize(uint32_t pWidth, uint32_t pHeight)
	{
		_viewportWidth = pWidth;
		_viewportHeight = pHeight;

		for (auto& entity : _entities)
			if (CameraComponent* cameraComp = entity->GetComponent<CameraComponent>())
				if (!cameraComp->fixedAspect) cameraComp->camera.SetViewportSize(pWidth, pHeight);

	}

}