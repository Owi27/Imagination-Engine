#include <Imgn.hpp>
#include <Imgn/ImgnTime.h>

namespace Imgn
{
    class EditorLayer : public Layer
    {
        ImgnWindow* _window;
        ImgnRenderer* _renderer;
        vk::DescriptorSet _sceneWindow = nullptr;

    public:
        EditorLayer() /*Constructor*/
        {
        }

        EditorLayer(ImgnWindow* pWindow, ImgnRenderer* pRenderer) /*Constructor*/
        {
            _renderer = pRenderer;
            _window = pWindow;
        }

        ~EditorLayer() /*Destructor*/
        {
        }

        /*Copy Constructor*/
        EditorLayer(const EditorLayer& pOther) = default;

        /*Copy Assignment Operator*/
        EditorLayer& operator=(const EditorLayer& pOther) = default;

        /*Move Constructor*/
        EditorLayer(EditorLayer&& pOther) noexcept = default;

        /*Move Assignment Operator*/
        EditorLayer& operator=(EditorLayer&& pOther) noexcept = default;

        /*Class Functions*/
        virtual void Sleep() override;
        virtual void WakeUp() override;
        virtual void OnImGuiRender() override;
        virtual void Dream(Time pTime) override;
        virtual void OnEvent(Event& pEvent) override;

    };
}